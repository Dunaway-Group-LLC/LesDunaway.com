Magister - single-page Bootstrap template
=============

Magister is a free responsive, single-page HTML5 template base on Twitter Bootstrap framework. 


License
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/


Features
-----------

A few features that make this template unique

* HTML is clean and fat-free, you will not find any useless code inside this template.
* Responsive design
* Overral quality, worth to be premium template.


Bug tracker
-----------

Found a bug? Please create an issue here on GitHub! 
https://github.com/pozh/Magister/issues



Credits
-------
* Design and development: **Sergey Pozhilov** - http://pozhilov.com
* Photos used in template: **Unsplash** - http://unsplash.com
* More free templates by Sergey: http://gettemplate.com
